import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs

HOME         =  xbmc.translatePath('special://home/')
dialog       =  xbmcgui.Dialog()
mode = 'killxmbc'
#####################################################
###       Multi Platform Closed 0 second          ###
#####################################################
###  Kill Media Center Xbmc/Kodi/Spmc ask prompt  ###
###                 By Who                        ###
#####################################################



def killxmbc():
    dialog  = xbmcgui.Dialog()
    choice = xbmcgui.Dialog().yesno('[B][COLOR green]Kill[/COLOR] [COLOR white]Media[/COLOR] [COLOR red]Center[/COLOR][/B]', '[B][COLOR green]Warning Do you want to immediately close.?[/COLOR]', '[COLOR white]Kodi/Xbmc/Spmc (Multi Platform & Save Setting)...[/COLOR]', '[COLOR red]You want to confirm (Yes) or (No)back add-ons programs...By @Who...[/COLOR][/B]', nolabel='[COLOR=red]No-(Return)[/COLOR]', yeslabel='[COLOR=green]Yes-(Kill)[/COLOR]') 
    
    if choice == 0:
        return
    elif choice == 1:
        pass
	os._exit(1)
    
    #################################
    if xbmc.getCondVisibility('system.platform.windows'): # Windows
      
			try:
				os.system('@ECHO off')
				os.system('tskill XBMC.exe')
			except: pass
			try:
				os.system('@ECHO off')
				os.system('tskill Kodi.exe')
			except: pass
			try:
				os.system('@ECHO off')
				os.system('tskill Spmc.exe')
			except: pass
			try:
				os.system('@ECHO off')
				os.system('TASKKILL /im Kodi.exe /f')
			except: pass
			try:
				os.system('@ECHO off')
				os.system('TASKKILL /im XBMC.exe /f')
			except: pass
			try:
				os.system('@ECHO off')
				os.system('TASKKILL /im Spmc.exe /f')
			except: pass
			
 
    if xbmc.getCondVisibility('system.platform.android'): # Android
        try: os.system('adb shell am force-stop org.spmc')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop com.semperpax.spmc16')
        except: pass 
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass     
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass  
        try: os.system('adb shell am force-stop org.smc')
        except: pass   
        try: os.system('adb shell am force-stop org.tvmc')
        except: pass             
        #

    if xbmc.getCondVisibility('system.platform.linux'): # Linux
        try: os.system('killall Spmc')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall SMC')
        except: pass
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 SMC.bin')
        except: pass
        try: os.system('killall -9 spmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        #

    if xbmc.getCondVisibility('system.platform.osx'): # Osx
        try: os.system('killall -9 Spmc')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        try: os.system('killall -9 SMC')
        except: pass
        try: os.system('killall -9 XBMC')
        except: pass
        #
    if xbmc.getCondVisibility('system.platform.ios'):
        print 'ios'
        #
    if xbmc.getCondVisibility('system.platform.atv2'):
        try: os.system('killall AppleTV')
        except: pass
        #
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop spmc')
        except: pass
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        try: os.system('sudo initctl stop tvmc')
        except: pass
        try: os.system('sudo initctl stop smc')
        except: pass
        #
    else:
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop spmc')
        except: pass
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        try: os.system('sudo initctl stop tvmc')
        except: pass
        try: os.system('sudo initctl stop smc')
        except: pass
		
def _save_settings( self ):
        """ saves settings """
        ok = Settings().save_settings( self.settings )
        if ( not ok ):
            ok = xbmcgui.Dialog().ok()
        
   
    #
if mode == 'killxmbc': killxmbc()