# plugin.program.chrome.launcher

This is my first repository. I decided to take on MODDING plugins for Kodi and this is my first project. In this MOD I have added the ability to save custom thumbnails to the plugin folder then they can be used with Chrome Launcher and Kodi will display your thumbs as fanart.

# NOTES

I am not a developer, that being said I will not be responsible if you mess up your device with this plugin. I am only making it available here in case there are other folks that would like to use custom fanart with Chrome Launcher. I did not develop this addon I simply modded it with my very few coding skills to make it do what I want and shared it here for others to use if they so desire.

You can put your custom thumbs in the plugin folder (plugin.program.chrome.launcher) under the resources/thumbs directory. Then when you are adding that site to Chrome Launcher you can specify the name of the thumbnail (ie. if you want a link to Google you can name your thumb google.png and save it to the thumbs directory) then you can specify the name of the image you saved in the add site window.
